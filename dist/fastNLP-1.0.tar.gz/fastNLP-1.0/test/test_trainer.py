def test_trainer():
    pass


if __name__ == "__main__":
    test_trainer()
