from fastNLP.loader.base_loader import BaseLoader


class EmbedLoader(BaseLoader):
    """docstring for EmbedLoader"""

    def __init__(self, data_name, data_path):
        super(EmbedLoader, self).__init__(data_name, data_path)
