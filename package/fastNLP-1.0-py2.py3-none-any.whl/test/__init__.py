import fastNLP

__all__ = ["fastNLP"]
